import tweepy
import os
from langdetect import detect
from dotenv import load_dotenv

# Load .env
load_dotenv()

# --- Auth Keys ---
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
ACCESS_SECRET = os.getenv("ACCESS_SECRET")
BOT_USERNAME = "@APEKURD"

# --- Tweepy Auth ---
auth = tweepy.OAuth1UserHandler(API_KEY, API_SECRET, ACCESS_TOKEN, ACCESS_SECRET)
api = tweepy.API(auth)

# --- Blacklist Filter ---
BLACKLIST = ["hate", "spam", "nsfw", "violence"]

def is_valid_tweet(text):
    try:
        lang = detect(text)
        if lang not in ["en", "ku"]:
            return False
        if len(text.strip()) < 15:
            return False
        if any(word in text.lower() for word in BLACKLIST):
            return False
        return True
    except:
        return False

def get_best_mention():
    mentions = api.mentions_timeline(count=20, tweet_mode="extended")
    filtered = []
    for tweet in mentions:
        if is_valid_tweet(tweet.full_text):
            filtered.append({
                "id": tweet.id,
                "user": tweet.user.screen_name,
                "likes": tweet.favorite_count
            })
    if not filtered:
        return None
    return sorted(filtered, key=lambda t: t["likes"], reverse=True)[0]

def share_best_tweet(tweet):
    tweet_url = f"https://twitter.com/{tweet['user']}/status/{tweet['id']}"
    status = f"@{tweet['user']} wrote 👇\n\n{tweet_url}"
    api.update_status(status=status)
    print("✅ Shared:", status)

if __name__ == "__main__":
    best = get_best_mention()
    if best:
        share_best_tweet(best)
    else:
        print("No valid tweet to share.")
